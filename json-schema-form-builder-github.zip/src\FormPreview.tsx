import type { JsonSchema, JsonValue } from "./schema";

type FormPreviewProps = {
  schema: JsonSchema;
  value: JsonValue;
  onChange: (value: JsonValue) => void;
};

export function FormPreview({ schema, value, onChange }: FormPreviewProps) {
  if (schema.type === "object" && schema.properties && isRecord(value)) {
    return (
      <div className="form-grid">
        {Object.entries(schema.properties).map(([key, childSchema]) => (
          <label key={key} className="field">
            <span>{childSchema.title ?? key}</span>
            <FormPreview
              schema={childSchema}
              value={value[key]}
              onChange={(nextValue) => {
                onChange({ ...value, [key]: nextValue });
              }}
            />
          </label>
        ))}
      </div>
    );
  }

  if (schema.type === "boolean") {
    return (
      <input
        type="checkbox"
        checked={Boolean(value)}
        onChange={(event) => onChange(event.target.checked)}
      />
    );
  }

  if (schema.type === "number") {
    return (
      <input
        type="number"
        value={typeof value === "number" ? value : 0}
        onChange={(event) => onChange(Number(event.target.value))}
      />
    );
  }

  if (schema.type === "array") {
    return (
      <textarea
        value={JSON.stringify(value ?? [], null, 2)}
        onChange={(event) => {
          try {
            onChange(JSON.parse(event.target.value) as JsonValue);
          } catch {
            onChange(event.target.value);
          }
        }}
      />
    );
  }

  return (
    <input
      type="text"
      value={typeof value === "string" ? value : String(value ?? "")}
      onChange={(event) => onChange(event.target.value)}
    />
  );
}

function isRecord(value: JsonValue): value is Record<string, JsonValue> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
