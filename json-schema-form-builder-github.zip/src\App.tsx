import { useMemo, useState } from "react";
import { FormPreview } from "./FormPreview";
import { formatJson, inferSchema, JsonValue } from "./schema";

const SAMPLE_JSON = `{
  "name": "Local Markdown Knowledge Vault",
  "stars": 128,
  "openSource": true,
  "tags": ["markdown", "local-first", "search"],
  "maintainer": {
    "name": "Your Name",
    "country": "CN"
  }
}`;

export default function App() {
  const [source, setSource] = useState(SAMPLE_JSON);
  const [formValue, setFormValue] = useState<JsonValue>(
    JSON.parse(SAMPLE_JSON) as JsonValue,
  );
  const [error, setError] = useState("");

  const schema = useMemo(() => inferSchema(formValue), [formValue]);

  function parseSource() {
    try {
      const parsed = JSON.parse(source) as JsonValue;
      setFormValue(parsed);
      setError("");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Invalid JSON.");
    }
  }

  function downloadSchema() {
    const blob = new Blob([formatJson(schema)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = "schema.json";
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main className="app-shell">
      <section className="editor-panel">
        <p className="eyebrow">Developer Tool</p>
        <h1>JSON Schema Form Builder</h1>
        <textarea
          aria-label="JSON source"
          value={source}
          onChange={(event) => setSource(event.target.value)}
          spellCheck={false}
        />
        {error && <p className="error">{error}</p>}
        <div className="actions">
          <button type="button" onClick={parseSource}>
            Infer schema
          </button>
          <button type="button" className="secondary" onClick={downloadSchema}>
            Export schema
          </button>
        </div>
      </section>

      <section className="form-panel">
        <header>
          <p className="eyebrow">Generated Form</p>
          <h2>Edit values from inferred fields</h2>
        </header>
        <FormPreview schema={schema} value={formValue} onChange={setFormValue} />
      </section>

      <section className="schema-panel">
        <header>
          <p className="eyebrow">JSON Schema</p>
          <h2>Export-ready output</h2>
        </header>
        <pre>{formatJson(schema)}</pre>
      </section>
    </main>
  );
}
