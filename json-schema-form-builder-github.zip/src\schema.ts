export type JsonValue =
  | string
  | number
  | boolean
  | null
  | JsonValue[]
  | { [key: string]: JsonValue };

export type JsonSchema = {
  type: string;
  title?: string;
  properties?: Record<string, JsonSchema>;
  items?: JsonSchema;
  required?: string[];
  default?: JsonValue;
};

export function inferSchema(value: JsonValue, title = "Root"): JsonSchema {
  if (Array.isArray(value)) {
    return {
      type: "array",
      title,
      items: value.length > 0 ? inferSchema(value[0], "Item") : { type: "string" },
      default: value,
    };
  }

  if (value !== null && typeof value === "object") {
    const entries = Object.entries(value);

    return {
      type: "object",
      title,
      properties: Object.fromEntries(
        entries.map(([key, child]) => [key, inferSchema(child, toTitle(key))]),
      ),
      required: entries.map(([key]) => key),
    };
  }

  return {
    type: value === null ? "null" : typeof value,
    title,
    default: value,
  };
}

export function toTitle(key: string) {
  return key
    .replace(/[_-]+/g, " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

export function formatJson(value: unknown) {
  return JSON.stringify(value, null, 2);
}
